const _ = require('lodash');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const AddcatwiseQuetion = require('../Models/addCatwisequetion.models');
const Category = require("../Models/addCategory.models");
const Subcategory = require("../Models/addSubCategory.models");
const multer = require('multer');
const path = require('path');

// Set up multer storage
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/'); // Set the uploads directory
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname); // Name the file with a timestamp
    },
});

const upload = multer({ storage: storage });

// Middleware to handle single file upload
exports.uploadImage = upload.single('icon');

exports.addqusetioncategory = catchAsync(async (req, res, next) => {
    const { question, correctOptionIndex } = req.body;
    const { categoryId, subcategoryId } = req.query; // Extract parameters from query
    const answer = JSON.parse(req.body.answer);

    // Validate input
    if (!question || !answer || correctOptionIndex === undefined) {
        return next(new AppError('Please provide all required fields: Title, question, answer, and correctOptionIndex.', 400));
    }

    // Ensure answer is an array
    if (!Array.isArray(answer)) {
        return next(new AppError('Answer must be an array.', 400));
    }

    // Validate correctOptionIndex
    if (correctOptionIndex < 0 || correctOptionIndex >= answer.length) {
        return next(new AppError('Invalid correctOptionIndex. It must be a valid index of the answer array.', 400));
    }

    // Check if the category exists
    const category = await Category.findById(categoryId);
    if (!category) {
        return res.status(404).json({
            status: 'fail',
            message: 'Category ID not found'
        });
    }

    // Check if the subcategory exists
    const subcategory = await Subcategory.findById(subcategoryId);
    if (!subcategory) {
        return res.status(404).json({
            status: 'fail',
            message: 'Subcategory ID not found'
        });
    }

    // If an icon image was uploaded, set the icon path
    // const icon = req.file ? req.file.originalname : '';

    // Create and save the new question category
    const newQuestionCategory = await AddcatwiseQuetion.create({ 
        question,
        answer, 
        correctOptionIndex,
        category: categoryId,
        subcategory: subcategoryId,
        categoryName: category.category, 
        subcategoryName: subcategory.subcategory 
    });

    res.status(201).json({
        status: 'success',
        data: {
            questionCategory: newQuestionCategory
        }
    });
});

exports.getqustioncategory = catchAsync(async (req, res, next) => {
    const quetion = await AddcatwiseQuetion.find();

    if (!quetion.length) {
        return res.status(404).json({
            status: 'fail',
            message: 'No questin found'
        });
    }

    return res.status(200).json({
        status: 'success',
        data: {
            quetion
        }
    });
});

exports.deletequstioncategory = catchAsync(async (req, res, next) => {
    const { id } = req.params;

    // Validate ID
    if (!id) {
        return next(new AppError('No ID provided. Please provide a valid question ID.', 400));
    }

    // Check if question exists
    const question = await AddcatwiseQuetion.findById(id);
    if (!question) {
        return next(new AppError('No question found with that ID.', 404));
    }

    // Delete the question
    await AddcatwiseQuetion.findByIdAndDelete(id);

    
    return res.status(200).json({
        status: 'success',
        message: 'Question deleted successfully.'
    });
});


exports.getcatwisequestion = catchAsync(async (req, res, next) => {
    const { categoryName } = req.params; // Extract the category name from the URL parameters
    console.log('categoryName =>', categoryName);

    // Validate input
    if (!categoryName) {
        return next(new AppError('Please provide a category name.', 400));
    }

    // Fetch all questions that belong to the provided category
    const questions = await AddcatwiseQuetion.find({ categoryName });

    console.log('Found questions =>', questions);

    if (questions.length === 0) {
        return next(new AppError('No questions found for this category.', 404));
    }

    // Send the response with the questions
    res.status(200).json({
        status: 'success',
        data: {
            questions
        }
    });
});
