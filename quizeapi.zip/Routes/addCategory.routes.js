const express = require('express');
const { addcatquetion ,deletecategory,getcategory} = require('../Controller/addCategory.controller');
const router = express.Router();

router.post('/addcategory', addcatquetion);
router.delete('/deletecategory/:id', deletecategory);
router.get('/getcategory', getcategory);

module.exports = router;
