const express = require('express');
const { addqusetioncategory,getqustioncategory,deletequstioncategory,getcatwisequestion} = require('../Controller/addCatwisequetion.controller');
const router = express.Router();

router.post('/addqusetioncategory', addqusetioncategory);
router.get('/getqustioncategory', getqustioncategory);
router.delete('/deletequstioncategory/:id', deletequstioncategory);
router.get('/getcatwisequestion/:categoryName', getcatwisequestion);



module.exports = router;