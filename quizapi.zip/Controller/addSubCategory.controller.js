const _ = require('lodash');
const catchAsync = require('../utils/catchAsync');
const multer = require('multer');
const AppError = require('../utils/appError');
const path = require('path');
const AddSubCategory = require('../Models/addSubCategory.models')


// const storage = multer.diskStorage({
//     destination: function (req, file, cb) {
//         cb(null, 'uploads');
//     },
//     filename: function (req, file, cb) {
//         cb(null, Date.now() + '-' + file.originalname); 
//     },
// });

// const upload = multer({ storage: storage });

// // Middleware to handle multiple file uploads
// exports.uploadImages = upload.single('icon');


exports.addsubcategory = catchAsync(async (req, res, next) => {
    const { subcategory } = req.body;

    // Validate input
    if (!subcategory) {
        return next(new AppError('Please provide a subcategory name.', 400));
    }

    // Check if the subcategory already exists
    const existingSubcategory = await AddSubCategory.findOne({ subcategory });

    if (existingSubcategory) {
        return next(new AppError('This subcategory already exists.', 400));
    }

    // Create and save the new subcategory
    const newSubcategory = await AddSubCategory.create({ subcategory });

    res.status(201).json({
        status: 'success',
        data: {
            subcategory: newSubcategory
        }
    });
});

exports.deletesubcategory = catchAsync(async (req, res, next) => {
    const { id } = req.params; // Assuming you want to delete by category ID

    if (!id) {
        return next(new AppError('Please provide a category ID.', 400));
    }

    // Find and delete the category
    const category = await AddSubCategory.findByIdAndDelete(id);

    if (!category) {
        return next(new AppError('No category found with that ID.', 404));
    }

    res.status(201).json({
        status: 'success',
        data: {
            category: category
        },
        message:"Delete data Done."
    });

});

exports.getsubcategory = catchAsync(async (req, res, next) => {
    const quetion = await AddSubCategory.find();

    if (!quetion.length) {
        return res.status(404).json({
            status: 'fail',
            message: 'No questin found'
        });
    }

    return res.status(200).json({
        status: 'success',
        data: {
            quetion
        }
    });
});