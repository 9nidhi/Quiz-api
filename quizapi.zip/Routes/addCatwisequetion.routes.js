const express = require('express');
const { addqusetioncategory,uploadImage,getqustioncategory,deletequstioncategory} = require('../Controller/addCatwisequetion.controller');
const router = express.Router();

router.post('/addqusetioncategory',uploadImage, addqusetioncategory);
router.get('/getqustioncategory', getqustioncategory);
router.delete('/deletequstioncategory/:id', deletequstioncategory);



module.exports = router;