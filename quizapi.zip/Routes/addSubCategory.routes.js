const express = require('express');
const { addsubcategory,deletesubcategory,getsubcategory} = require('../Controller/addSubCategory.controller');
const router = express.Router();

router.post('/addsubcategory', addsubcategory);
router.delete('/deletesubcategory/:id', deletesubcategory);
router.get('/getsubcategory', getsubcategory);


module.exports = router;