const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const subcatquestionaddSchema = new Schema({
	
    subcategory: {
        type: String,
        unique: true, // Ensure subcategory names are unique
        required: true // Make the subcategory field required
    }
}, {timestamps: true});

const AddSubCategory = mongoose.model('addSubcategory', subcatquestionaddSchema);

module.exports = AddSubCategory;
