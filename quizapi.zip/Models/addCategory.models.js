const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const catquestionaddSchema = new Schema({
	category: {
		type: String,
        unique: true
	},
    // subcategory:{
    //     type: String,
    // },
    // Title:{
    //     type:String
    // },
    // icon:{
    //     type:String
    // },
    // question:{
    //     type:String
    // },
    // answer:[{
    //     type: String,   
    // }],
    // correctOptionIndex: { type: Number, required: true },
}, {timestamps: true});

const AddCategory = mongoose.model('addcatquestion', catquestionaddSchema);

module.exports = AddCategory;
